import random


def color(number):
    if number == 0:
        return "b"
    else:
        return "r"


def pick_envelope(switch, verbose):
    # initialize a 2d array to store data
    envelope = [[0 for i in range(2)] for j in range(2)]
    # randomly put the red ball
    rand_red = random.randint(0, 1)
    if rand_red == 0:
        envelope[0][0] = 1
    else:
        envelope[1][0] = 1

    # randomly select one envelope
    rand_enve = random.randint(0, 1)

    # randomly select a ball from the envelope
    rand_ball = random.randint(0, 1)

    if verbose:
        print("envelope 0: " + color(envelope[0][0]) + " " + color(envelope[0][1]))
        print("envelope 1: " + color(envelope[1][0]) + " " + color(envelope[1][1]))
        print("I picked envelope " + repr(rand_enve))

    # if pick the red one at the first time
    if envelope[rand_enve][rand_ball] == 1:
        if verbose:
            print("and drew a " + color(1))
        return True
    else:
        if verbose:
            print("and drew a " + color(0))

        if switch:
            if verbose:
                print("switch to envelope " + repr(1 - rand_enve))
            # if after switch, the envelope is all black, return false
            if envelope[1 - rand_enve][0] == 0 and envelope[1 - rand_enve][1] == 0:
                return False

        # if do not switch and the other one is also zero, return false
        else:
            if envelope[rand_enve][1 - rand_ball] == 0:
                return False

    return True


# def testpick():
#     if pick_envelope(True, verbose=True):
#         print("T")
#     else:
#         print("F")
#
# testpick()

def run_simulation(n):
    succ1 = 0
    succ2 = 0
    print("After " + repr(n) + " simulations:")
    for i in range(n):
        if pick_envelope(True, False):
            succ1 += 1

    for i in range(n):
        if pick_envelope(False, False):
            succ2 += 1

    print("Switch successful: " + repr((succ1 * 100) / n) + "%")
    print("No-Switch successful: " + repr((succ2 * 100) / n) + "%")


run_simulation(10000)
